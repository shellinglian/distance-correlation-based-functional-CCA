generate.data.lin<-function(n,ntime,sigma=0.5){

  nbasis<-15
  mybasismatrix<-cos(pi* outer((1:ntime)/ntime,1:nbasis) )
  xi<-matrix(rnorm(nbasis*n),nrow=nbasis)/(1:nbasis)
  eta<-matrix(rnorm(nbasis*n),nrow=nbasis)/(1:nbasis)
  
  eta[2,]<-xi[2,]+xi[3,]+rnorm(n)*sigma
  X<-mybasismatrix%*%xi; Y<-mybasismatrix%*%eta
  return(list(Y=Y,X=X))
}



generate.data.nonlin<-function(n,ntime,sigma=0.1){
 
  nbasis<-15
  mybasismatrix<-cos(pi* outer((1:ntime)/ntime,1:nbasis) )
  xi<-matrix(rnorm(nbasis*n),nrow=nbasis)/(1:nbasis)
  eta<-matrix(rnorm(nbasis*n),nrow=nbasis)/(1:nbasis)
  eta[1,]<-2*(xi[1,]+xi[2,])^2+rnorm(n)*sigma
  X<-mybasismatrix%*%xi; Y<-mybasismatrix%*%eta

  return(list(Y=Y,X=X))
}

generate.data.null<-function(n,ntime,sigma=0.1){
  
  nbasis<-15
  mybasismatrix<-cos(pi* outer((1:ntime)/ntime,1:nbasis) )
  xi<-matrix(rnorm(nbasis*n),nrow=nbasis)/(1:nbasis)
  eta<-matrix(rnorm(nbasis*n),nrow=nbasis)/(1:nbasis)
  #eta[1,]<-2*(xi[1,]+xi[2,])^2+rnorm(n)*sigma
  X<-mybasismatrix%*%xi; Y<-mybasismatrix%*%eta
  
  return(list(Y=Y,X=X))
}



generate.data<-function(n,ntime,sigma=0.1){

  nbasis<-15
  mybasismatrix<-cos(pi* outer((1:ntime)/ntime,1:nbasis) )

  xi<-matrix(rnorm(nbasis*n),nrow=nbasis)/(1:nbasis)
  eta<-matrix(rnorm(nbasis*n),nrow=nbasis)/(1:nbasis)

  z<-runif(n,-2,2)
  xi[1,]<-z^3+rnorm(n)*sigma; eta[1,]<-log(abs(z))/2+rnorm(n)*sigma
  eta[2,]<-2*(xi[2,]+xi[3,])^2+rnorm(n)*sigma
  eta[4,]<-(xi[4,])+rnorm(n)*sigma


  X<-mybasismatrix%*%xi; Y<-mybasismatrix%*%eta

  return(list(Y=Y,X=X))
}

