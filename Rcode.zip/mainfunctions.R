CCA<-function(X,Y){

Xsvd<-svd(t(X)%*%X); Ysvd<-svd(t(Y)%*%Y)
Xinv<-Xsvd$u%*%diag(1/(Xsvd$d+1e-10))%*%t(Xsvd$u)
Xinvhalf<-Xsvd$u%*%diag(1/sqrt(Xsvd$d+1e-10))%*%t(Xsvd$u)
Yinv<-Ysvd$u%*%diag(1/(Ysvd$d+1e-10))%*%t(Ysvd$u)
Yinvhalf<-Ysvd$u%*%diag(1/sqrt(Ysvd$d+1e-10))%*%t(Ysvd$u)

temp<-Xinvhalf%*%t(X)%*%Y%*%Yinv%*%t(Y)%*%X%*%Xinvhalf
alpha<-as.vector(Xinvhalf%*%svd(temp)$u[,1])

temp<-Yinvhalf%*%t(Y)%*%X%*%Xinv%*%t(X)%*%Y%*%Yinvhalf
beta<-as.vector(Yinvhalf%*%svd(temp)$u[,1])

return(list(alpha=alpha/sqrt(sum(alpha^2)),beta=beta/sqrt(sum(beta^2))))
}

SCA<-function(X,Y){
  XYsvd<-svd(t(X)%*%Y)
  alpha<-XYsvd$u[,1]; beta<-XYsvd$v[,1]
  return(list(alpha=alpha/sqrt(sum(alpha^2)),beta=beta/sqrt(sum(beta^2))))
}

dCovCCA<-function(alpha,beta,X,Y){
 tstep<-0.001
 alpha<-alpha/sqrt(sum(alpha^2)); beta<-beta/sqrt(sum(beta^2))
 for (iter in 1:100){
  temp<-computedCovgrad(alpha,beta,X,Y)
  alpha<-alpha+tstep*temp$gradalpha
  beta<-beta+tstep*temp$gradbeta

  #normalize
  alpha<-alpha/sqrt(sum(alpha^2)); beta<-beta/sqrt(sum(beta^2));

  #cat(computedCor(alpha,beta,X,Y)[1:2],"\n")
 }
return(list(alpha=alpha,beta=beta))
}




dCorCCA2<-function(alpha,beta,X,Y){
 tstep<-0.003
 for (iter in 1:100){
  
  temp<-computedCorgrad(alpha,beta,X,Y)
  alpha<-alpha+tstep*temp$gradalpha
  beta<-beta+tstep*temp$gradbeta

  alpha<-alpha/sqrt(sum(alpha^2)); beta<-beta/sqrt(sum(beta^2))

  #cat(computedCor(alpha,beta,X,Y)[1:2],"\n")
 }

 return(list(alpha=alpha,beta=beta))
}


