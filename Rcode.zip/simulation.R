library(fda)
library(magic)
library(mvtnorm)
library(splines)

source("generate.data.R")

source("tools.R")
source("mainfunctions.R")
#set.seed(1000)
n<-100; ntime<-200; sigma<-0.1
grid<-seq(0,1,length=ntime)

ninternal=16 # number basis is ninternal+4
mybreaks<-seq(0,1,length=ninternal+2) 
mybasis<-create.bspline.basis(rangeval=c(0,1),breaks=mybreaks)
mybasismatrix<-getbasismatrix(seq(0,1,length=ntime),mybasis) #ntimes*nbasis matrix

windows(); par(mfrow=c(4,3));

mydata<-generate.data.nonlin(n,ntime,sigma)
oriX<-mydata$X; oriY<-mydata$Y
oriX<-oriX-apply(oriX,1,mean)
oriY<-oriY-apply(oriY,1,mean) #oriX,Y never change
funX<-oriX; funY<-oriY 

#use FPCA to project the functional data to functional scores
  myfdx<-Data2fd(argvals=grid,y=funX,mybasis) # number column of X is n
  mypcax<-pca.fd(myfdx,nharm=mybasis$nbasis-1)
  myscoresx<-mypcax$score #now number of ROW is n

  myfdy<-Data2fd(argvals=grid,y=funY,mybasis) # number column of X is n
  mypcay<-pca.fd(myfdy,nharm=mybasis$nbasis-1)
  myscoresy<-mypcay$score #now number of ROW is n

  allX<-myscoresx; allY<-myscoresy
  allX<-t(t(allX)-apply(allX,2,mean))
  allY<-t(t(allY)-apply(allY,2,mean))

  ###################################
  ####### CCA #######################
  ###################################
  cat("CCA\n")
  J<-5
  
  temp<-CCA(as.matrix(allX[,1:J]),as.matrix(allY[,1:J]))
  alpha<-temp$alpha; beta<-temp$beta
  alphafun<-as.vector(mybasismatrix%*%mypcax$harmonics$coefs[,1:J]%*%alpha)
  betafun<-as.vector(mybasismatrix%*%mypcay$harmonics$coefs[,1:J]%*%beta)
  alphafun<-alphafun/sqrt(sum(alphafun^2)); betafun<-betafun/sqrt(sum(betafun^2))
    

  cor.cca<-cor(t(funX)%*%alphafun,t(funY)%*%betafun)
  dcor.cca<-computedCor(alphafun,betafun,t(funX),t(funY))[1]

 
  plot(alphafun,xlab="",ylab="",main="alpha")
  plot(betafun,xlab="",ylab="",main="beta")
  plot(alphafun%*%funX,betafun%*%funY,,xlab="",ylab="",main="")
  



###################################
####### SCA #######################
###################################
cat("SCA\n")


  
  J<-5
  
  temp<-SCA(as.matrix(allX[,1:J]),as.matrix(allY[,1:J]))
  alpha<-temp$alpha; beta<-temp$beta
  alphafun<-as.vector(mybasismatrix%*%mypcax$harmonics$coefs[,1:J]%*%alpha)
  betafun<-as.vector(mybasismatrix%*%mypcay$harmonics$coefs[,1:J]%*%beta)
  alphafun<-alphafun/sqrt(sum(alphafun^2)); betafun<-betafun/sqrt(sum(betafun^2))
    

  cor.sca<-cor(t(funX)%*%alphafun,t(funY)%*%betafun)
  dcor.sca<-computedCor(alphafun,betafun,t(funX),t(funY))[1]

  plot(alphafun,xlab="",ylab="",main="alpha")  
  plot(betafun,xlab="",ylab="",main="beta")
  plot(alphafun%*%funX,betafun%*%funY,xlab="",ylab="",main="")

  
 
 
  
  ##############################
  ####### dCor-CCA  ###########
  ##############################
  cat("dCor-CCA\n")
  
  J<-5
  
  init<-initialize(allX[,1:J],allY[,1:J])
  initalpha<-init$alpha;initbeta<-init$beta
  
  temp<-dCorCCA2(initalpha[1:J],initbeta[1:J],as.matrix(allX[,1:J]),as.matrix(allY[,1:J]))
  alpha<-temp$alpha; beta<-temp$beta
  alphafun<-as.vector(mybasismatrix%*%mypcax$harmonics$coefs[,1:J]%*%alpha)
  betafun<-as.vector(mybasismatrix%*%mypcay$harmonics$coefs[,1:J]%*%beta)
  alphafun<-alphafun/sqrt(sum(alphafun^2)); betafun<-betafun/sqrt(sum(betafun^2))
  
  cor.dcor<-cor(t(funX)%*%alphafun,t(funY)%*%betafun)
  dcor.dcor<-computedCor(alphafun,betafun,t(funX),t(funY))[1]
  
  plot(alphafun,xlab="",ylab="",main="alpha")
  plot(betafun,xlab="",ylab="",main="beta")
  plot(alphafun%*%funX,betafun%*%funY,xlab="",ylab="",main="")
  
  

##############################
####### dCov-CCA #############
##############################
cat("dCoV-CCA\n")

  J<-5

    init<-initialize(allX[,1:J],allY[,1:J])
    initalpha<-init$alpha;initbeta<-init$beta

  temp<-dCovCCA(initalpha[1:J],initbeta[1:J],as.matrix(allX[,1:J]),as.matrix(allY[,1:J]))
  alpha<-temp$alpha; beta<-temp$beta
  alphafun<-as.vector(mybasismatrix%*%mypcax$harmonics$coefs[,1:J]%*%alpha)
  betafun<-as.vector(mybasismatrix%*%mypcay$harmonics$coefs[,1:J]%*%beta)
  alphafun<-alphafun/sqrt(sum(alphafun^2)); betafun<-betafun/sqrt(sum(betafun^2))
   
  
  cor.dcov<-cor(t(funX)%*%alphafun,t(funY)%*%betafun)
  dcor.dcov<-computedCor(alphafun,betafun,t(funX),t(funY))[1]

  plot(alphafun,xlab="",ylab="",main="alpha")
  plot(betafun,xlab="",ylab="",main="beta")
  plot(alphafun%*%funX,betafun%*%funY,xlab="",ylab="",main="")

