computedCov<-function(alpha,beta,X,Y){
  x<-as.vector(X%*%alpha)
  y<-as.vector(Y%*%beta)
  n<-length(x)
  tildeA<-abs(outer(x,x,"-"))
  tildeB<-abs(outer(y,y,"-"))
  H<-diag(n)-matrix(1,nrow=n,ncol=n)/n
  A<-H%*%tildeA%*%H; B<-H%*%tildeB%*%H;
  sum(A*B)/n^2
}

computedCor<-function(alpha,beta,X,Y){
  x<-as.vector(X%*%alpha)
  y<-as.vector(Y%*%beta)
  n<-length(x)
  tildeA<-abs(outer(x,x,"-"))
  tildeB<-abs(outer(y,y,"-"))
  H<-diag(n)-matrix(1,nrow=n,ncol=n)/n
  A<-H%*%tildeA%*%H; B<-H%*%tildeB%*%H;
  return(c( sum(A*B)/sqrt(sum(A^2)*sum(B^2)), sum(A*B)/n/n, sqrt(sum(A^2))/n, sqrt(sum(B^2))/n ) )
}

computedCovgrad<-function(alpha,beta,X,Y){
  x<-as.vector(X%*%alpha)
  y<-as.vector(Y%*%beta)
  n<-length(x)
  
  Cx<-(outer(x,x,"-")>0)*2-1
  Cy<-(outer(y,y,"-")>0)*2-1
  tildeA<-abs(outer(x,x,"-"))
  tildeB<-abs(outer(y,y,"-"))
  H<-diag(n)-matrix(1,nrow=n,ncol=n)/n
  A<-H%*%tildeA%*%H; B<-H%*%tildeB%*%H;
  
  D<-B*Cx; diag(D)<-0
  gradalpha<-t(apply(D,1,sum))%*%X
  D<-A*Cy; diag(D)<-0
  gradbeta<-t(apply(D,1,sum))%*%Y

  return(list(gradalpha=as.vector(gradalpha),gradbeta=as.vector(gradbeta)))
}


computedCorgrad<-function(alpha,beta,X,Y){
  x<-as.vector(X%*%alpha)
  y<-as.vector(Y%*%beta)
  n<-length(x)
  
  Cx<-(outer(x,x,"-")>0)*2-1
  Cy<-(outer(y,y,"-")>0)*2-1
  tildeA<-abs(outer(x,x,"-"))
  tildeB<-abs(outer(y,y,"-"))
  H<-diag(n)-matrix(1,nrow=n,ncol=n)/n
  A<-H%*%tildeA%*%H; B<-H%*%tildeB%*%H;

  Dx<-B*Cx; diag(Dx)<-0
  Dy<-A*Cy; diag(Dy)<-0

  Da<-A*Cx; diag(Da)<-0
  Db<-B*Cy; diag(Db)<-0
  
  gradalpha<-t(apply(Dx,1,sum))%*%X/sum(A*B)-t(apply(Da,1,sum))%*%X/sum(A^2)
 
  gradbeta<-t(apply(Dy,1,sum))%*%Y/sum(A*B)-t(apply(Db,1,sum))%*%Y/sum(B^2)

  return(list(gradalpha=as.vector(gradalpha),gradbeta=as.vector(gradbeta)))
}


initialize.old<-function(X,Y,nsample=10){
  n<-dim(X)[1]
  curmax<-0
  curmaxi<-1; curmaxj<-1
  seqi<-sort(sample(1:n,nsample))
  seqj<-sort(sample(1:n,nsample))
  for (i in seqi){
    for (j in seqj){
      temp<-computedCor(X[i,],Y[j,],X,Y)[1]
      #cat(i,j,temp,"\n")
      if (temp>curmax){ curmax<-temp; curmaxi<-i; curmaxj<-j}
    }
  }
  return(list(alpha=as.vector(X[curmaxi,]),beta=as.vector(Y[curmaxj,])))
}



initialize<-function(X,Y,nsample=10){
  n<-dim(X)[1]
  curmax<-0
  seqi<-sort(sample(1:n,nsample))
  for (i in seqi){
    seqj<-sort(sample(1:n,nsample))
    for (j in seqj){
      temp<-computedCor(X[i,],Y[j,],X,Y)[1]
      if (temp>curmax){ curmax<-temp; curalpha<-X[i,]; curbeta<-Y[j,]}
    }
  }
  return(list(alpha=as.vector(curalpha),beta=as.vector(curbeta)))
}


